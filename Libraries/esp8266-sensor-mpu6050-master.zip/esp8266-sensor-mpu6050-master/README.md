# esp8266-sensor-mpu6050
A set of arduino sketches that use the esp8266 and the MPU-6050

This setup uses an ESP8266 and a GY-521 IMU board.

Full details of all of the code can be found here:
https://olivertechnologydevelopment.wordpress.com/2017/08/17/esp8266-sensor-series-gy-521-imu-part-1/