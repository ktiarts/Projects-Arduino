const char* ssid = "My_SSID";
const char* password = "My_PASSWORD";
const char* mqtt_server = "server.example_mqtt_server.com";
const uint16_t mqtt_port = 123456;
const char* clientID = "My_Client_ID";
const char* mqtt_username = "My_MQTT_Username";
const char* mqtt_password = "My_MQTT_Password";
