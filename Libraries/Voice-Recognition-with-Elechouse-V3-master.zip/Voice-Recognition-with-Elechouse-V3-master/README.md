# Voice-Recognition-with-Elechouse-V3
Arduino library and other files needed to use the elechouse v3 voice recognition module.
