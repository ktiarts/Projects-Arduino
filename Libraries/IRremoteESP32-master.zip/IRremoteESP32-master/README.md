# IRremoteESP32
Infrared remote library for ESP32: send and receive infrared signals with multiple protocols. Based on: https://github.com/markszabo/IRremoteESP8266

Still in development
