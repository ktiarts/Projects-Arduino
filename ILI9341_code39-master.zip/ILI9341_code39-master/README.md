# Code 39 Barcode Generator for Adafruit ILI9341
Code 39 Barcode Generator for Adafruit ILI9341 using with ESP8266 (Arduino Compatible)

![work image](https://i.gyazo.com/fb62b2eae718c5a9a9dc085c93e4f025.png)


# License
Copyright (C) Kyosuke Inoue ([@kyoro353](https://twitter.com/kyoro353))

This software is released under the MIT License.
[http://opensource.org/licenses/mit-license.php](http://opensource.org/licenses/mit-license.php)
